//Ejercicio 1 - Test evaluador
function evaluarRendimiento(nota) {
  if (nota >= 0 && nota < 2) return "Muy mal";
  if (nota >= 2 && nota < 5) return "Mal";
  if (nota >= 5 && nota < 6) return "Tan cerca pero tan lejos";
  if (nota >= 6 && nota < 8) return "Bien!";
  if (nota >= 8 && nota <= 10) return "Muy bien!!";
  return "Nota inválida";
}

console.log("Ejercicio 1:");
console.log(evaluarRendimiento(7));  // Bien!


//Ejercicio 2 - THE BIGGEST ONE
function biggestOne(num1, num2, palabra) {
  if (num1 > num2) return num1;
  if (num2 > num1) return num2;
  return palabra[0] + palabra[palabra.length - 1];
}

console.log("Ejercicio 2:");
console.log(biggestOne(16, 2, "Haz"));  // 16
console.log(biggestOne(3, 3, "Haz"));   // Hz


//Ejercicio 3 - FROOTLOOP
let frutasYVerduras = [ {fruta:"banana"}, {verdura:"apio"}, {fruta:"manzana"}, 
    {fruta:"frutilla"},{verdura:"zanahoria"}, {fruta:"kiwi"}, {fruta:"sandia"},
    {fruta:"melon"}, {verdura:"repollo"}, {fruta:"mango"}
];
function filtrarFrutas(arr) {
  const frutas = arr
    .filter(item => item.fruta)
    .map(item => item.fruta);
  return { frutas };
}

console.log("Ejercicio 3:");
console.log(filtrarFrutas(frutasYVerduras));



//Ejercicio 4 - SODA DISPENSER
let unidades = [1, 2, 3, 4];
let gaseosas = ["cocacola", "sprite", "fanta", "seven up"];
function dispenserGaseosas(unidades, gaseosas) {
  let gaseosasEnStock = {};
  for (let i = 0; i < gaseosas.length; i++) {
    gaseosasEnStock[gaseosas[i]] = unidades[i] || 0;
  }
  return gaseosasEnStock;
}

console.log("Ejercicio 4:");
console.log(dispenserGaseosas(unidades, gaseosas));


//Ejercicio 5 - AÑO DE NACIMIENTO
let personas = [
  {nombre: "Juan", edad: 19},
  {nombre: "Mario", edad: 22}
];

function agregarAnioNacimiento(personas) {
  const anioActual = new Date().getFullYear();
  return personas.map(persona => ({
    ...persona, nacimiento: anioActual - persona.edad
  }));
}
console.log("Ejercicio 5:");
console.log(agregarAnioNacimiento(personas));
