function fizzBuzz2() {
  let palabra1 = document.getElementById("palabra1").value;
  let palabra2 = document.getElementById("palabra2").value;
  let hastaNumero = parseInt(document.getElementById("Numero").value);
  let fizzNum = parseInt(document.getElementById("fizzNum").value);
  let buzzNum = parseInt(document.getElementById("buzzNum").value);

  let resultado = [];

  for (let i = 1; i <= hastaNumero; i++) {
    let texto = "";

    if (i % fizzNum === 0) texto += palabra1;
    if (i % buzzNum === 0) texto += palabra2;

    resultado.push(texto || i);
  }

  document.getElementById("resultado").textContent = resultado.join(", ");
}
