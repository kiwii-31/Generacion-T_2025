const body = document.querySelector("body");
const img = document.querySelector(".mouse");

let seguirMouse = false;

body.addEventListener("mousedown", () => {
    seguirMouse = true;
});

body.addEventListener("mousemove", (e) => {
    if (seguirMouse) {
        img.style.top = e.clientY + "px";
        img.style.left = e.clientX + "px";
    }
});
