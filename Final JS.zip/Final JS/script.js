const words = [
  "Gomoso Sue", "Condolleza Marie","Sabina",
  "Honoria","Tránsito","Higinio","Ufano", "Hilario",
  "Jacinta", "Cándido","Teodosia","Cástulo",
  "Gervasia","Epifanio","Gaudelia","Eufemio", "Eustaquio",
  "Brígida","Melitón","Leonila","Nicanor","Martina","Régulo","Teodora",
  "Teódulo","Tiburcio","Celso"
];

const h1 = document.getElementById("randomWord");
const container = document.querySelector(".contenedor");
const textInput = document.getElementById("text");
const timeSpan = document.getElementById("timeSpan");
const scoreSpan = document.getElementById("score");
const endtheGame = document.getElementById("end-game-container");
const main = document.querySelector(".main");

let palabraAleatoria;
let time = 10;
let score = 0;
let timeInterval;

function randomWords() {
  const i = Math.floor(Math.random() * words.length);
  return words[i];
}

function addToDOM() {
  palabraAleatoria = randomWords();
  h1.innerText = palabraAleatoria;
  endtheGame.style.display = "none";
}

textInput.addEventListener("input", (e) => {
  let palabraIngresada = e.target.value;
  if (palabraIngresada === palabraAleatoria) {
    updateScore();
    addToDOM();
    time += 3;
    e.target.value = "";
    timeSpan.innerText = `${time}s`;
  }
});

function actualizarTiempo() {
  time--;
  timeSpan.innerText = `${time}s`;
  if (time === 0) {
    clearInterval(timeInterval);
    GameOver();
    textInput.disabled = true;
    main.style.display = "none"; 
    endtheGame.style.display = "block";
  }
}

function updateScore() {
  score++;
  scoreSpan.innerText = score;
}

function startGame() {
  addToDOM();
  textInput.focus();
  timeInterval = setInterval(actualizarTiempo, 1000);
}

function GameOver() {
  endtheGame.innerHTML = `
    <h1>Game Over</h1>
    <p>Tu Score es: ${score}</p>
    <button onclick="location.reload()">¿Jugar de Nuevo?</button>
  `;
}

startGame();
