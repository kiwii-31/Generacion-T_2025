function calcularJubilacion() {
  let edad = document.getElementById("edad").value;
  let genero = document.getElementById("genero").value;
  let resultado = document.getElementById("resultado");

  if (edad === "" || genero === "") {
    resultado.textContent = "Complete todos los campos, por favor 🥺";
    return;
  }

  edad = Number(edad);

  if (genero === "mujer" && edad >= 60) {
    resultado.textContent = "¡Puede jubilarse!, cumple con la edad 😄";
  } else if (genero === "hombre" && edad >= 65) {
    resultado.textContent = "¡Puede jubilarse!, cumple con la edad 😄";
  } else {
    resultado.textContent = "Todavía no puede jubilarse no cumple con la edad 😞";
  }
}